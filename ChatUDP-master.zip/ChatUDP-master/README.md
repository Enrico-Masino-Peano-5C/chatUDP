# ChatUDP

esercizio: creare una chat tra client e server tramite una comunicazione UDP
